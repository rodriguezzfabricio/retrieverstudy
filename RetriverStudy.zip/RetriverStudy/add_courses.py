from website import create_app, db
from website.models import Course

app = create_app()

with app.app_context():
    # List of subjects
    subjects = [
        "Africana Studies", "Management of Aging Services", "American Studies", "Ancient Studies",
        "Arabic", "Asian Studies", "American Sign Language", "Biology", "Chemistry", 
        "Community Leadership", "Critical Sexuality Studies", "Economics", 
        "Emergency & Disaster Health Systems", "English", "Engineering Management", "French", 
        "Global Studies", "Gender Women Sexuality Studies", "Human Context Science & Tech", 
        "History", "Linguistics", "Mathematics", "Media and Communication Studies", 
        "Modern Lang & Linguistics", "Music", "Philosophy", "Physics", "Political Science", 
        "Psychology", "Religious Studies", "Russian", "Science", "Sociology", "Social Work", 
        "Spanish", "Statistics", "Theatre"
    ]

    # Sample classes to add for each subject
    sample_classes = ["101 - Introduction", "201 - Intermediate", "301 - Advanced"]

    # Adding the courses to the database
    for subject in subjects:
        for sample_class in sample_classes:
            course_name = f"{subject} {sample_class}"
            new_course = Course(course_name=course_name, student_count=0, subject=subject)
            db.session.add(new_course)

    # Commit changes to the database
    db.session.commit()
    print("Courses added to the database successfully.")
