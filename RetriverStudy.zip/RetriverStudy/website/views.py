from flask import Blueprint, render_template
from .models import Course

views = Blueprint('views', __name__)

@views.route('/')
def home():
    return render_template('home.html')

@views.route('/study')
def study():
    # Query the database for all subjects and courses
    subjects = Course.query.with_entities(Course.subject).distinct().all()
    courses = Course.query.all()

    return render_template('study.html', subjects=subjects, courses=courses)
